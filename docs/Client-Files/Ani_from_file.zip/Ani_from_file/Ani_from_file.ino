#include <Adafruit_NeoPixel.h>
#include <SPIFFS.h>

#define DATA_PIN 13
#define BRIGHTNESS 255
#define DEFAULT_FRAMEDURATION 100

int NUM_LEDS = 12;  // Default strip length // OBRISATI
Adafruit_NeoPixel strip = Adafruit_NeoPixel(NUM_LEDS, DATA_PIN, NEO_GRBW + NEO_KHZ800);  // OBRISATI


// Global variables
Adafruit_NeoPixel stripL, stripR;

int dataPinL, dataPinR;

int brightnessL, brightnessR;
uint8_t typeL, typeR;  // Store the NEO type

int stripLengthL = 0;  // Length of the left strip
int stripLengthR = 0;  // Length of the right strip

// Assuming the maximum possible entries in the colortable.conf is 256
char colorTable[256][5];  // Color table matrix
int colorTableRows = 0;  // Number of rows (entries) in the color table


int skipPixelsL = 0;
int skipPixelsR = 0;



bool debugMode = false;




String currentAnimationFile = "startup.ani";
String nextAnimationFile = "";

void setup() {
    Serial.begin(115200);
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFS ERROR");
        return;
    }

   if (SPIFFS.exists("startup.ani")) {
        currentAnimationFile = "startup.ani";
    } else {
        Serial.println("No startup.ani found. Listening for external triggers.");
    }
    loadConfig();  // Load configuration from config.conf
    loadColorTable();  // Load color table from colortable.conf

    stripL = Adafruit_NeoPixel(stripLengthL, dataPinL, typeL + NEO_KHZ800);
    stripL.setBrightness(brightnessL);
    stripL.show();  // Initialize with all LEDs off

    stripR = Adafruit_NeoPixel(stripLengthR, dataPinR, typeR + NEO_KHZ800);
    stripR.setBrightness(brightnessR);
    stripR.show();  // Initialize with all LEDs off
//------------------------------------------------------------------------- obrisati 3 linije
    strip = Adafruit_NeoPixel(12, 13, NEO_GRBW + NEO_KHZ800);
    strip.setBrightness(255);
    strip.show();  // Initialize with all LEDs off

    listAllFilesInSPIFFS();
}


void debugPrint(String DebugText){
  if (debugMode) Serial.println(DebugText);
}

void loop() {
    if (nextAnimationFile != "") {
        currentAnimationFile = nextAnimationFile;
        nextAnimationFile = "";
    }

    playAnimation(currentAnimationFile);
}
String extractValue(String data, String key, String defaultValue = "") {
    int startPos = data.indexOf(key);
    if (startPos == -1) return defaultValue;
    startPos += key.length();
    int endPos = data.indexOf(' ', startPos);
    if (endPos == -1) endPos = data.length();  // If there's no space after the key, use the line's end
    return data.substring(startPos, endPos);
}


void loadConfig() {
    if (!SPIFFS.exists("/config.conf")) {
        Serial.println("Error: config.conf not found!");
        return;
    }

    File configFile = SPIFFS.open("/config.conf", "r");
    String currentSection = "";

    while (configFile.available()) {
        String line = configFile.readStringUntil('\n');
        line.trim();  // Remove any extraneous white spaces
        
        // Check if the line is a section header
        if (line.startsWith("[")) {
            currentSection = line;
            continue;
        }

        // Skip empty lines or comment lines
        if (line.length() == 0 || line.startsWith("#") || line.startsWith("//")) {
            continue;
        }

        if (currentSection == "[strips]") {
            // Parse and set the properties of the LED strips
            int pin = extractValue(line, "P:").toInt();
            String type = extractValue(line, "T:");
            int length = extractValue(line, "L:").toInt();
            int skip = extractValue(line, "S:", "0").toInt();  // Default to 0 if not specified
            int brightness = extractValue(line, "B:", "255").toInt();  // Default to 255 if not specified

            if (stripL.numPixels() == 0) {  // If stripL has not been configured
                stripL = Adafruit_NeoPixel(length, pin, convertTypeToNeoPixel(type));
                stripL.setBrightness(brightness);
                skipPixelsL = skip;
            } else {
                stripR = Adafruit_NeoPixel(length, pin, convertTypeToNeoPixel(type));
                stripR.setBrightness(brightness);
                skipPixelsR = skip;
            }
        } else if (currentSection == "[input]") {
            // Parse and set the properties of the input pins
            int pin = extractValue(line, "P:").toInt();
            pinMode(pin, INPUT_PULLUP);
            // Other configurations for the input pins go here...

        } else if (currentSection == "[output]") {
            // Parse and set the properties of the output pins
            int pin = extractValue(line, "P:").toInt();
            String state = extractValue(line, "S:");
            pinMode(pin, OUTPUT);
            digitalWrite(pin, state == "L" ? LOW : HIGH);

        } else if (currentSection == "[debug]") {
            // Determine if debug mode should be enabled or not
            if (line == "debug=1") {
                debugMode = true;
            } else {
                debugMode = false;
            }
        }
    }

    configFile.close();
}


uint8_t convertTypeToNeoPixel(String type) {
    if (type == "RGB") return NEO_RGB;
    if (type == "RGBW") return NEO_RGBW;
    if (type == "GRB") return NEO_GRB;
    if (type == "GRBW") return NEO_GRBW;
    if (type == "BRG") return NEO_BRG;
    if (type == "BRGW") return NEO_BRGW;
    return NEO_RGB;  // Default type
}

void loadColorTable() {
    if (SPIFFS.exists("/colortable.conf")) {
        debugPrint("Loading color table...");
        File colorTableFile = SPIFFS.open("/colortable.conf", "r");
        colorTableRows = 0;
        while (colorTableFile.available() && colorTableRows < 256) {
            String line = colorTableFile.readStringUntil('\n');
            line.trim();
            if (line.length() > 0 && !line.startsWith("#") && !line.startsWith("//") && line.indexOf('=') != -1) {
                colorTable[colorTableRows][0] = line.charAt(0);
                String rgbw = line.substring(line.indexOf('=') + 1);
                int idx = 1;
                for (int i = 0; i < 4; i++) {
                    int nextComma = rgbw.indexOf(',', idx);
                    if (nextComma == -1) {
                        nextComma = rgbw.length();
                    }
                    colorTable[colorTableRows][idx] = rgbw.substring(idx - 1, nextComma).toInt();
                    idx = nextComma + 1;
                }
                colorTableRows++;
            }
        }
        colorTableFile.close();
        debugPrint("Color table loaded with " + String(colorTableRows) + " entries.");
    } else {
        debugPrint("Color table file not found!");
    }
}

uint8_t determineType(String type) {
    if (type == "RGB") return NEO_RGB;
    if (type == "RGBW") return NEO_RGBW;
    if (type == "GRB") return NEO_GRB;
    if (type == "GRBW") return NEO_GRBW;
    if (type == "BRG") return NEO_BRG;
    if (type == "BRGW") return NEO_BRGW;
    return NEO_RGB;  // Default
}


void playAnimation(String filename) {
    File file = SPIFFS.open('/' + filename.c_str(), "r");
    if (!file) {
        debugPrint("Failed to open animation file: " + filename);
        return;
    }

    String line;
    while (file.available()) {
        line = file.readStringUntil('\n');
        line.trim();

        // Check for comments and ignore
        if (line.startsWith("#") || line.startsWith("//")) continue;

        // Special command: frame duration
        if (line.indexOf('|') != -1) {
            int duration = line.substring(0, line.indexOf('|')).toInt();
            updateLEDs(line.substring(line.indexOf('|') + 1));
            delay(duration);
            continue;
        }

        // Special command: frame fade duration (not implemented here due to complexity)
        // TODO: Implement fade logic if necessary

        // Special command: PAUSE
        if (line.startsWith("PAUSE")) {
            int pauseDuration = line.substring(6).toInt();
            delay(pauseDuration);
            continue;
        }

        // Special command: STOP
        if (line.startsWith("STOP")) {
            while (true) {
                // Keeps the current LED state indefinitely
            }
        }

        // If it's an animation filename, set the next animation file
        if (line.endsWith(".ani")) {
            nextAnimationFile = line;
            break;
        }

        // Special command: GPIO pin trigger
        if (line.startsWith("PIN")) {
            int pin = line.substring(4, line.indexOf(' ', 4)).toInt();
            String state = line.substring(line.lastIndexOf(' ') + 1);
            digitalWrite(pin, state == "HIGH" ? HIGH : LOW);
            continue;
        }

        // Default: Treat line as animation frame
        updateLEDs(line);
        delay(100);  // Default frame duration
    }

    file.close();
}

void updateLEDs(String line) {
    int idx = 0;
    for (int i = 0; i < line.length(); i++) {
        if (line[i] == ';') continue;

        if (line[i] == '-') {
            if (line.substring(i, i+3) == "-->") {
                // Fill remaining LEDs with the last color
                while (idx < (stripLengthL + stripLengthR)) {
                    // Use the last color for the rest of the LEDs
                    idx++;
                }
                break;
            } else {
                int dashEnd = line.indexOf('>', i);
                int repeatCount = line.substring(i + 1, dashEnd).toInt();
                for (int j = 0; j < repeatCount; j++) {
                    setPixelFromChar(line[i-1], idx);
                    idx++;
                }
                i = dashEnd;
                continue;
            }
        }

        setPixelFromChar(line[i], idx);
        idx++;
    }
}

void setPixelFromChar(char c, int idx) {
    for (int i = 0; i < colorTableRows; i++) {
        if (colorTable[i][0] == c) {
            int r = colorTable[i][1];
            int g = colorTable[i][2];
            int b = colorTable[i][3];
            int w = colorTable[i][4];
            if (idx < stripLengthL) {
                stripL.setPixelColor(idx, r, g, b, w);
            } else {
                stripR.setPixelColor(idx - stripLengthL, r, g, b, w);
            }
            return;
        }
    }
}

// Function to display and clear the buffer
void showAndClear() {
    stripL.show();
    stripR.show();
    for (int i = 0; i < stripLengthL; i++) {
        stripL.setPixelColor(i, 0, 0, 0, 0);
    }
    for (int i = 0; i < stripLengthR; i++) {
        stripR.setPixelColor(i, 0, 0, 0, 0);
    }
}
void listAllFilesInSPIFFS() {
    Serial.println("\n\n--- Listing all files in SPIFFS: ---");
    
    File root = SPIFFS.open("/");
    File file = root.openNextFile();
    
    while(file) {
        Serial.print("\n\n  File: ");
        Serial.println(file.name());

        Serial.println("  Content:");
        while (file.available()) {
            String line = file.readStringUntil('\n');
            Serial.println("    " + line);
        }

        file = root.openNextFile();
    }

    Serial.println("\n--- End of file list ---\n\n");
}




















void parseAndUpdateStrip(String line) {
    int ledIdx = 0;
    for (int i = 0; i < line.length(); i++) {
        if (line[i] == ';') {
            ledIdx++;
            continue;
        }
        if (line[i] == '-') {
            int dashEnd = line.indexOf('>', i);
            String repeatValue = line.substring(i + 1, dashEnd);
            int repeatCount = repeatValue.toInt();
            char colorCode = line[dashEnd + 1];
            setPixelColorFromCode(ledIdx, colorCode);
            for (int j = 0; j < repeatCount; j++) {
                setPixelColorFromCode(ledIdx + j, colorCode);
            }
            ledIdx += repeatCount;
            i = dashEnd;
        } else {
            setPixelColorFromCode(ledIdx, line[i]);
            ledIdx++;
        }
    }
}

void setPixelColorFromCode(int index, char code) {
    switch (code) {
        case 'R': strip.setPixelColor(index, strip.Color(255, 0, 0, 0)); break;
        case 'G': strip.setPixelColor(index, strip.Color(0, 255, 0, 0)); break;
        case 'B': strip.setPixelColor(index, strip.Color(0, 0, 255, 0)); break;
        case 'w': strip.setPixelColor(index, strip.Color(255, 255, 255, 0)); break;
        case 'W': case 'x': strip.setPixelColor(index, strip.Color(0, 0, 0, 255)); break;
        case 'C': strip.setPixelColor(index, strip.Color(0, 255, 255, 0)); break;
        case 'M': strip.setPixelColor(index, strip.Color(255, 0, 255, 0)); break;
        case 'Y': strip.setPixelColor(index, strip.Color(255, 255, 0, 0)); break;
        case 'A': strip.setPixelColor(index, strip.Color(255, 80, 0, 0)); break;
        case 'O': strip.setPixelColor(index, strip.Color(255, 165, 0, 0)); break;
        case '.': strip.setPixelColor(index, strip.Color(0, 0, 0, 0)); break;
        case 'X': strip.setPixelColor(index, strip.Color(255, 255, 255, 255)); break;
    }
}
