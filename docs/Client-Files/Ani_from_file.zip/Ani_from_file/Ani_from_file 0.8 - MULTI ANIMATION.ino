#include <Adafruit_NeoPixel.h>
#include <SPIFFS.h>

#define DATA_PIN 13
#define BRIGHTNESS 255
#define DEFAULT_FRAMEDURATION 100

int NUM_LEDS = 12;  // Default strip length
Adafruit_NeoPixel strip = Adafruit_NeoPixel(NUM_LEDS, DATA_PIN, NEO_GRBW + NEO_KHZ800);

String currentAnimationFile = "/startup.txt";
String nextAnimationFile = "";

void setup() {
    Serial.begin(115200);
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFS ERROR");
        return;
    }
    listAllFilesInSPIFFS();

    strip.begin();
    strip.setBrightness(BRIGHTNESS);
    strip.show();  // Initialize with all LEDs off
}

void loop() {
    if (nextAnimationFile != "") {
        currentAnimationFile = nextAnimationFile;
        nextAnimationFile = "";
    }

    playAnimation(currentAnimationFile);
}

void playAnimation(String filename) {
    Serial.print("Attempting to open file: ");
    Serial.println(filename);

    File file = SPIFFS.open(filename.c_str());
    if (!file) {
        Serial.print("Failed to open: ");
        Serial.println(filename);
        return;
    } else {
        Serial.print("Successfully opened: ");
        Serial.println(filename);
    }

    while (file.available()) {
        String line = file.readStringUntil('\n');
        line.trim();

        if (line.startsWith("L:")) {
            NUM_LEDS = line.substring(2).toInt();
            strip.updateLength(NUM_LEDS);
            strip.show(); // Update the strip length and clear it
            continue;
        }

        if (line.endsWith(".txt")) {
            nextAnimationFile ="/" + line;
            break;  // Exit out of the while loop to let the main loop handle the file switch
        }

        if (line.startsWith("STOP")) {
            while (true) {
                strip.show();
                delay(DEFAULT_FRAMEDURATION);
            }
        } else if (line.startsWith("PAUSE")) {
            int pauseDuration = line.substring(6).toInt();
            delay(pauseDuration);
            continue;
        } else if (line.indexOf('|') != -1) {
            int dividerPos = line.indexOf('|');
            int customDuration = line.substring(0, dividerPos).toInt();
            parseAndUpdateStrip(line.substring(dividerPos + 1));
            strip.show();
            delay(customDuration);
        } else {
            parseAndUpdateStrip(line);
            strip.show();
            delay(DEFAULT_FRAMEDURATION);
        }
    }

    file.close();
}

void listAllFilesInSPIFFS() {
    Serial.println("\n\n--- Listing all files in SPIFFS: ---");
    
    File root = SPIFFS.open("/");
    File file = root.openNextFile();
    
    while(file) {
        Serial.print("\n\n  File: ");
        Serial.println(file.name());

        Serial.println("  Content:");
        while (file.available()) {
            String line = file.readStringUntil('\n');
            Serial.println("    " + line);
        }

        file = root.openNextFile();
    }

    Serial.println("\n--- End of file list ---\n\n");
}

void parseAndUpdateStrip(String line) {
    int ledIdx = 0;
    for (int i = 0; i < line.length(); i++) {
        if (line[i] == ';') {
            ledIdx++;
            continue;
        }
        if (line[i] == '-') {
            int dashEnd = line.indexOf('>', i);
            String repeatValue = line.substring(i + 1, dashEnd);
            int repeatCount = repeatValue.toInt();
            char colorCode = line[dashEnd + 1];
            setPixelColorFromCode(ledIdx, colorCode);
            for (int j = 0; j < repeatCount; j++) {
                setPixelColorFromCode(ledIdx + j, colorCode);
            }
            ledIdx += repeatCount;
            i = dashEnd;
        } else {
            setPixelColorFromCode(ledIdx, line[i]);
            ledIdx++;
        }
    }
}

void setPixelColorFromCode(int index, char code) {
    switch (code) {
        case 'R': strip.setPixelColor(index, strip.Color(255, 0, 0, 0)); break;
        case 'G': strip.setPixelColor(index, strip.Color(0, 255, 0, 0)); break;
        case 'B': strip.setPixelColor(index, strip.Color(0, 0, 255, 0)); break;
        case 'w': strip.setPixelColor(index, strip.Color(255, 255, 255, 0)); break;
        case 'W': case 'x': strip.setPixelColor(index, strip.Color(0, 0, 0, 255)); break;
        case 'C': strip.setPixelColor(index, strip.Color(0, 255, 255, 0)); break;
        case 'M': strip.setPixelColor(index, strip.Color(255, 0, 255, 0)); break;
        case 'Y': strip.setPixelColor(index, strip.Color(255, 255, 0, 0)); break;
        case 'A': strip.setPixelColor(index, strip.Color(255, 80, 0, 0)); break;
        case 'O': strip.setPixelColor(index, strip.Color(255, 165, 0, 0)); break;
        case '.': strip.setPixelColor(index, strip.Color(0, 0, 0, 0)); break;
        case 'X': strip.setPixelColor(index, strip.Color(255, 255, 255, 255)); break;
    }
}
